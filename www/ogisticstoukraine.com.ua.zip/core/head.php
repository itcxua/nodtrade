<?
//head
?>
<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title><?=$title?></title>
        <link rel="stylesheet preload" as="style" href="<?=URL?>/css/preload.min.css" />
        <link rel="stylesheet preload" as="style" href="<?=URL?>/css/icomoon.css" />
        <link rel="stylesheet preload" as="style" href="<?=URL?>/css/libs.min.css" />
        <link rel="icon" href="<?=URL?>/favicon.png" type="image/x-icon">
        <link rel="stylesheet" href="<?=URL?>/css/<?=$css_name?>.min.css" />
          <meta property="og:title" content="<?=$title?>">
<meta property="og:description" content="<?=$descript?>">
<meta property="og:image" content="<?=URL?>/img/daf.png">
<meta name="description" content="<?=$descript?>">
<meta name="keywords" content="<?=$key?>">
    </head>
    <body>
        <header class="header" data-page="home2">
            <div class="header_panel">
                <div class="container d-flex justify-content-center justify-content-md-between align-items-center">
                    <span class="header_panel-logo">
                        <a class="logo d-inline-flex align-items-center" href="<?=URL?>/">
                            <span class="logo_media">
                                <svg width="56px" height="37px" viewBox="0 0 56 37" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <g fill="currentColor" transform="translate(0.000000, -0.000000)">
                                            <g transform="translate(0.000000, 0.000000)">
                                                <path
                                                    d="M37.9730366,0 L56,18.5 L37.9730366,37 L20.0419919,18.5 L25.8616371,12.5121359 L23.0545408,9.458807 L14.4823984,18.5 L30.1911192,35 L28,37 L23.0545408,32 L18.195333,37 L0,18.5 L18.195333,0 L36.0014273,18.5 L30.1911192,24.6483396 L32.9085797,27.4399418 L41.6203395,18.5 L25.8616371,2.43040321 L28,0 L32.9085797,5.20234095 L37.9730366,0 Z M17.9818927,4.43392989 L4.64144645,18.5147247 L17.9818927,32.5955195 L21.0810871,29.6079919 L10.1321127,18.5 L21.0810871,7.28442361 L17.9818927,4.43392989 Z M37.7101843,4.43392989 L35.2883953,7.44356982 L46.1323481,18.5 L35.2883953,29.7451953 L37.7101843,32 L51.3914285,18.5147247 L37.7101843,4.43392989 Z M28,14.5941371 L24.4227574,18.5 L28,22.3996382 L31.7636086,18.5147247 L28,14.5941371 Z"
                                                ></path>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
                            </span>
                            <span class="logo_text">ФЛП Егоров Д.В.</span>
                        </a>
                    </span>
                    <div class="header_panel-links">
                        <a class="header_panel-links_link btn btn--regular" href="<?=URL?>/calculator">Калькулятор тарифов</a>
                        <a class="header_panel-links_link btn btn--regular bordered" href="mail:info@logisticstoUkraine.com">info@logisticstoUkraine.com</a>
                    </div>
                </div>
            </div>
            <nav class="header_nav">
                <div class="container d-flex flex-wrap flex-lg-nowrap align-items-center justify-content-between flex-lg-row-reverse">
                    <a class="header_nav-tel h5" href="tel:+380634615444">+38 (063) 461-54-44</a>
                    <a
                        class="header_nav-trigger"
                        href="#"
                        id="headerTrigger"
                        data-bs-toggle="collapse"
                        data-bs-target="#headerMenu"
                        aria-controls="headerMenu"
                    >
                        <svg
                            width="100%"
                            height="100%"
                            enable-background="new 0 0 32 32"
                            viewBox="0 0 32 32"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="m29.5625 5.3092h-27.125c-1.06854 0-1.9375.86896-1.9375 1.9375s.86896 1.9375 1.9375 1.9375h27.125c1.06812 0 1.9375-.86896 1.9375-1.9375s-.86938-1.9375-1.9375-1.9375z"
                                fill="currentColor"
                            />
                            <path
                                d="m29.5625 14.0625h-27.125c-1.06854 0-1.9375.86896-1.9375 1.9375s.86896 1.9375 1.9375 1.9375h27.125c1.06812 0 1.9375-.86896 1.9375-1.9375s-.86938-1.9375-1.9375-1.9375z"
                                fill="currentColor"
                            />
                            <path
                                d="m29.562 22.816h-27.125c-1.0685 0-1.9375 0.8689-1.9375 1.9375 0 1.0685 0.86896 1.9375 1.9375 1.9375h27.125c1.0681 0 1.9375-0.86896 1.9375-1.9375 0-1.0686-0.86938-1.9375-1.9375-1.9375z"
                                fill="currentColor"
                            />
                        </svg>
                    </a>
                    <div class="header_nav-wrapper collapse" id="headerMenu">
                        <ul class="header_nav-menu d-flex flex-column flex-lg-row">
                             <li class="header_nav-menu_item">
                                <a class="nav-item nav-link" href="<?=URL?>/" data-page="home">Главная</a>
                            </li>
                          
                            <li class="header_nav-menu_item">
                                <a class="nav-item nav-link" href="calculator" data-page="<?=URL?>/about">О нас</a>
                            </li>
                            <li class="header_nav-menu_item dropdown">
                                <a
                                    class="nav-link nav-item dropdown-toggle d-inline-flex align-items-center"
                                    href="<?=URL?>/services"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#servicesMenu"
                                    data-trigger="dropdown"
                                    aria-expanded="false"
                                    aria-controls="servicesMenu"
                                    data-page="services"
                                >
                                    Услуги
                                    <i class="icon-caret-down-solid icon"></i>
                                </a>
                                <div class="dropdown-menu collapse" id="servicesMenu">
                                    <ul class="dropdown-list">
                                        <li class="list-item" data-main="true">
                                            <a class="dropdown-item nav-item" data-page="services" href="<?=URL?>/services" data-main="true">
                                                Услуги
                                            </a>
                                        </li>
                                        <li class="list-item">
                                            <a class="dropdown-item nav-item" data-page="service" href="<?=URL?>/transportation_bulk_cargo">Перевозки насыпных грузов</a>
                                        </li>
                                         <li class="list-item">
                                            <a class="dropdown-item nav-item" data-page="service" href="<?=URL?>/transportation_liquid_cargo">Перевозки наливных грузов</a>
                                        </li>
                                         <li class="list-item">
                                            <a class="dropdown-item nav-item" data-page="service" href="<?=URL?>/transportation_complete_cargo">Перевозки комплектных грузов</a>
                                        </li>
                                         <li class="list-item">
                                            <a class="dropdown-item nav-item" data-page="service" href="<?=URL?>/transportation_project_cargo">Проектные перевозки</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                      <li class="header_nav-menu_item">
                                <a class="nav-item nav-link" href="calculator" data-page="<?=URL?>/calculator">Калькулятор</a>
                            </li>
                            <li class="header_nav-menu_item">
                                <a class="nav-item nav-link" href="contacts" data-page="<?=URL?>/contacts">Контакты</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            
        </header>