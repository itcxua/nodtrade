<?php
define("URL","https://testing.allpartsinoneplace.com");
$dev = true;
$deb = 1;
if ($deb == 0){
	error_reporting(E_ALL | E_STRICT);
	ini_set('display_errors','On');
} else {
	ini_set('display_errors','Off');
}
session_start();
$starttime=microtime();
$starttime=explode(" ",$starttime);
$starttime=$starttime[0]+$starttime[1];
define("ROOT",$_SERVER["DOCUMENT_ROOT"]);
?>