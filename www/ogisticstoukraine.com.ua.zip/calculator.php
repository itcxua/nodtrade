<?php
$title='Калькулятор тарифов| "ФЛП Егоров Д.В."';
$css_name="calculator";
require_once 'core/config.php';
require_once 'core/head.php';
?> <style> .textcenter {
            display: flex;
            justify-content: center;
            align-items: center;
           
        }</style>
        <header class="page">
            <div class="page_overlay"></div>

            <div class="container">
                <div class="page_card d-flex flex-column">
                    <h1 class="page_card-title">Калькулятор тарифов</h1>
                    <ul class="page_card-breadcrumbs breadcrumbs">
                        <li class="page_card-breadcrumbs_item item">
                            <a class="link" href="<?=URL?>/">Главная</a>
                        </li>

                        <li class="page_card-breadcrumbs_item item">
                            <span class="current">Калькулятор тарифов</span>
                        </li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- homepage content start -->
        <main class="section">
            <section class="calculator">
                <div class="container">
                    <div class="calculator_header">
                        <h2 class="textcenter calculator_header-title">Форма расчета тарифа</h2>
                        <p class="textcenter calculator_header-text">Чтобы рассчитать тариф заполните необходимые данные</p>
                    </div>
                   <form class="calculator_form form" id="calculatorForm">
        <div class="calculator_form-row">
            <div class="column">
                <label class="label" for="truckloadCalculator">ТИП АВТОМОБИЛЯ</label>
                <select id="truckloadCalculator">
                    <option value="Тент">Тент</option>
                    <option value="Зерновоз">Зерновоз</option>
                    <option value="Цистерна">Цистерна</option>
                </select>
            </div>
            <div class="column">
                <label class="label" for="serviceCalculator">РАССТОЯНИЕ (km)</label>
                <input class="field required" type="number" id="serviceCalculator" placeholder="0" />
            </div> 
            <div class="column">
                <label class="label" for="resultCalculator">ИТОГ:</label>
                
                  <div id="resultCalculator" class="result-text">0 грн</div>
            </div>
        </div><div class="textcenter">
        <button class="btn btn--regular" type="button" onclick="calculate()">Рассчитать</button></div>
    </form>
                </div>
            </section>
            <div class="container">
                <section class="banner">
                    <div class="container">
                        <span class="banner_bg">
                            <picture>
                                <source data-srcset="img/beck3.webp" srcset="img/beck3.webp" />
                                <img class="lazy" data-src="img/beck3.webp" src="beck3.webp" alt="media" />
                            </picture>

                            <span class="banner_bg-overlay"></span>
                        </span>
                        <div class="banner_content">
                            <h3 class="banner_content-title">Наши услуги</h3>
                            <p class="banner_content-text"><div style="color:#fff;">Наша компания предоставляет широкий спектр услуг по перевозке грузов, включая перевозки насыпных, наливных, полетных грузов.</div></p>
                            <a class="banner_content-btn btn btn--split" href="<?=URL?>/services">
                                <span class="main">Услуги</span>
                                <span class="icon-caret_right icon"></span>
                            </a>
                        </div>
                    </div>
                </section>
            </div><br><br>
            <?
    require_once 'core/contact.php';
?>
        </main>
          <script>
        let prices = {};

        // Загрузка цен из файла prices.json
        fetch('prices.json')
            .then(response => response.json())
            .then(data => {
                prices = data;
            })
            .catch(error => console.error('Ошибка загрузки цен:', error));

        function calculate() {
        const type = document.getElementById('truckloadCalculator').value;
        const distance = parseFloat(document.getElementById('serviceCalculator').value);
        const pricePerKm = prices[type];
        const resultElement = document.getElementById('resultCalculator');
        if (pricePerKm !== undefined && !isNaN(distance) && distance >= 0) {
            const total = pricePerKm * distance;
            resultElement.textContent = total.toFixed(2) + ' грн';
        } else {
            resultElement.textContent = 'Введите корректное расстояние';
        }
    }
    </script>
<?
    require_once 'core/foot.php';
?> 
